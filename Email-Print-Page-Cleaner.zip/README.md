Gmail-Print-Page-Cleaner
========================

Removes some things from the Gmail print email page, mainly removing the Gmail logo at the top.
