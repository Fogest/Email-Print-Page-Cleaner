Gmail-Print-Page-Cleaner
========================

Will remove user chosen elements from Gmails print view.
